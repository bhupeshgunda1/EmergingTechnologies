import datetime

today_date = datetime.datetime.now()
print(today_date)
